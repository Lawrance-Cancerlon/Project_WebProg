<div class="rounded-lg py-4 px-8 bg-slate-200 shadow-lg flex flex-row justify-between" id="navbar">
    <div class="flex flex-row gap-4 items-center">
        <a class="navbar-brand" href="/"><?php echo e(env('APP_NAME')); ?></a>
        <a href="/home" class="nav-link <?php echo e($page == 'home' ? 'active' : ''); ?>">Beranda</a>
        <a href="/explore" class="nav-link <?php echo e($page == 'explore' ? 'active' : ''); ?>">Jelajah</a>
        <a href="/post" class="nav-link <?php echo e($page == 'post' ? 'active' : ''); ?>">Buka Usaha</a>
    </div>

    <div class="flex flex-row gap-4 items-center">
        <?php if(Auth::check()): ?>
                <a href="/portfolio" class="nav-link <?php echo e($page == 'portfolio' ? 'active' : ''); ?>">Portofolio</a>
                <a href="/profile" class="dropdown-item">Profil</a>
                <a href="/logout" class="dropdown-item">Keluar</a>
        <?php else: ?>
                <a href="/login" class="nav-link <?php echo e($page == 'login' ? 'active' : ''); ?>">Masuk</a>
                <a href="/register" class="nav-link <?php echo e($page == 'register' ? 'active' : ''); ?>">Daftar</a>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH D:\Coding Environment\Project_WebProg\resources\views/components/navbar.blade.php ENDPATH**/ ?>