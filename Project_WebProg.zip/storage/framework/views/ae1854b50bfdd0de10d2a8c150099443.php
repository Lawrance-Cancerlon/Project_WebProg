

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('components.navbar', ['page' => 'explore'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex flex-col items-center">
      
    </div>

    <div class="flex items-center justify-center h-full p-8">
        <div class="w-full h-full rounded-lg flex flex-col justify-center items-center gap-8 py-20" id="banner" style="background-image: url('storage/assets/home_banner.png'); background-size: cover;">
                <h1 class="text-8xl text-surface">
                    Telusuri jasa yang kamu inginkan
                </h1>
                <form action="/explore" method="get" class="flex flex-row w-full max-w-md mb-4 gap-4">
                    <input type="text" name="search" id="search" class="input w-full rounded-l-md" placeholder="Cari pekerjaan jasa..." value="<?php echo e($search ? $search : ''); ?>">
                    <button type="submit" class="btn btn-primary rounded-r-md bg-blue-500 text-white px-4 py-2">
                        Cari
                    </button>
                </form>
        </div>
    </div>



    <div class="bg-surface-container grid grid-cols-1 md:grid-cols-3 gap-4 p-8">
        <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-surface shadow-md rounded-lg overflow-hidden">
                <div class="flex flex-col p-8 gap-4 items-start">
                    <h5 class="text-4xl text-on-surface font-bold"><?php echo e($service->title); ?></h5>
                    <h6 class="text-on-surface-variant text-md"><?php echo e($service->category()->first()->name); ?></h6>
                    <p class="text-on-surface text-lg"><?php echo e($service->description); ?></p>
                    <p class="text-on-secondary font-semibold px-4 py-2 bg-secondary w-fit rounded">IDR <?php echo e($service->salary); ?></p>
                    <a href="/services?id=<?php echo e($service->id); ?>" class="btn w-full text-center">Lihat</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-3 mt-3 text-center">
                <h2 class="text-2xl font-bold">
                    Tidak ada jasa
                </h2>
            </div>
        <?php endif; ?>
    </div>
    <div class="flex justify-center mt-4">
        <?php echo e($services->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding Environment\Project_WebProg\resources\views/explore.blade.php ENDPATH**/ ?>