<?php
    use App\Models\Service;
    use App\Http\Controllers\PageController;
?>


<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('components.navbar', ['page' => 'portfolio'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    


    <div class="grid grid-cols-4 overflow-visible p-12">

        <div class="col-span-2 flex flex-col justify-start gap-4">

            <h1 class="text-2xl font-bold mb-4">Pesanan Jasa</h1>
            <div class="flex flex-wrap -mx-2">
                <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="w-full md:w-1/3 px-2 mb-4">
                        <div class="bg-surface shadow-md rounded overflow-hidden">
                            <div class="py-12 px-8">
                                <h5 class="text-lg text-on-surface font-semibold mb-4"><?php echo e(Service::find($job->service_id)->title); ?></h5>
                                <a href="profile?id=<?php echo e($job->user_id); ?>" class="py-2 px-2
                                    hover:bg-primary hover:text-on-primary rounded-full bg-primary-container
                                    text-on-primary-container mb-8 w-fit flex flex-row justify-start items-center">
                                    
                                   <img class="rounded-full h-auto w-12 object-cover" src="<?php echo e(PageController::getPicture($job->user()->first()->name)); ?>" />
                
                
                                        <span class="px-4"><?php echo e($job->user()->first()->name); ?></span>
                                
                                </a>
                                <p class="text-on-surface-variant"><?php echo e($job->description); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="w-full text-center">Anda belum mendapatkan aplikasi</p>
                <?php endif; ?>
            </div>  

        </div>


        <div class="col-span-2 flex flex-col justify-start gap-4">

            <h1 class="text-2xl font-bold mb-4">Lamaran Anda</h1>
            <div class="flex flex-wrap -mx-2">
                <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="w-full md:w-1/3 px-2 mb-4">
                        <div class="bg-surface shadow-md rounded-lg overflow-hidden">
                            <div class="py-12 px-8">
                                <h5 class="text-lg text-on-surface font-semibold mb-4"><?php echo e(Service::find($application->service_id)->title); ?></h5>
                                <a href="profile?id=<?php echo e($application->service()->first()->user_id); ?>" class="py-2 px-2
                                    hover:bg-primary hover:text-on-primary rounded-full bg-primary-container
                                    text-on-primary-container mb-8 w-fit flex flex-row justify-start items-center">
                                    
                                   <img class="rounded-full h-auto w-12 object-cover" src="<?php echo e(PageController::getPicture($application->service()->first()->user()->first()->name)); ?>" />
                
                
                                        <span class="px-4"><?php echo e($application->service()->first()->user()->first()->name); ?></span>
                                
                                </a>
                                <p class="text-on-surface-variant"><?php echo e($application->description); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="w-full text-center">Anda belum melamar</p>
                <?php endif; ?>
            </div>


        </div>


    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding Environment\Project_WebProg\resources\views/portfolio.blade.php ENDPATH**/ ?>